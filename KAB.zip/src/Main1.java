import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner; 

public class Main1 {

	
public static void main(String[]args) {
ReadPlayerData();
ReadGameData();
ReadStaffData();
  boolean Exit = false; 



 while(!Exit){ 
	 System.out.print("Choose : 1.AddPlayer 2.RemovePlayer 3.DisplayTeaminfo 4.AddStaff  5.RemoveStaff 6.DisplayStaffinfo 7.AddGame 8.DisplaySeasonInfo , 10.exit \n");
	  Scanner Sc = new Scanner(System.in); 
	  int Choice = Sc.nextInt(); 

  switch(Choice) {
  case 1:
	  AddPlayer();
    break;
  case 2:
	  RemovePlayer(); 
    break;
  case 3:
	  DisplayTeamInfo();
	 break;
  case 4:
	  AddStaff();
	 break;
  case 5:
	  RemoveStaff();
	 break; 
  case 6:
	  DisplayStaffInfo();
	  break ;
  case 7 :
	  AddGame () ;
	  break ;
  case 8:
	  DisplayChampInfo();
	  break ;
  case 9 :
	  Exit = true ;
  Save();
  }
	  
}

	
	}
public static void AddPlayer() {
    Scanner Sc = new Scanner(System.in); 
    System.out.printf("insert Name, Position, Age, Price, Salary \n");
    String Name = Sc.nextLine(); 
    String Pos = Sc.nextLine();
    int Age = Sc.nextInt();
    int price = Sc.nextInt(); 
    int Salary = Sc.nextInt(); 
    System.out.print( " Name = " + Name +" Age = "+ Age + " Position = "+ Pos+" Salary = "+Salary+"\n");
    Player P = new Player(Name,Age,Pos,price,Salary);
    Player.Team.add(P);
}
public static void RemovePlayer() {
    System.out.printf("Enter Name \n");
    Scanner Sc = new Scanner(System.in); 
    String Name = Sc.nextLine(); 
    System.out.print(Name);
  int i = Player.findIndexByName(Name) ;
  Player.Team.remove(i);
	
}


public static void AddStaff() {
    Scanner Sc = new Scanner(System.in); 
    System.out.printf(" Insert name, job, age, Salary \n");
    String Name = Sc.nextLine(); 
    String Job = Sc.nextLine();
    int Age = Sc.nextInt();
    int Salary = Sc.nextInt(); 
    System.out.print("Name = "+Name+" Age = "+Age +" Job = "+Job+"Salary = "+Salary+"\n");
    Staff S = new Staff(Name,Age,Job,Salary);
    Staff.AllStaff.add(S);
}
public static void RemoveStaff() {
    System.out.printf("Enter Name \n");
    Scanner Sc = new Scanner(System.in); 
    String Name = Sc.nextLine(); 
int size = Staff.AllStaff.size();
for (int i = 0; i< size;i++) {
	if(Name.equals(Staff.AllStaff.get(i).getName())) {
		System.out.print("Removed \n");
		Staff.AllStaff.remove(i);
	break ;	
	}
   }
}
public static void AddGame () {
    System.out.printf("Enter opponent, Goals Scorers, Yellow Cards , Red Cards, Assists , Goalsconceded, GoalsScored, Assists \n");
	 Scanner Sc = new Scanner(System.in); 
	   String opponent = Sc.nextLine(); 	
	    String  GSS = Sc.nextLine(); 	
	    String  Y = Sc.nextLine(); 	
	    String  R = Sc.nextLine(); 	
	    String  A = Sc.nextLine(); 	
	    int GC =Sc.nextInt();
		 int GSD=Sc.nextInt();

  Game G = new Game(opponent,GC,GSD,GSS,Y,R,A);
  Game.Championship.add(G);
  updatePlayersStatus(G);
}
public static void DisplayTeamInfo() {
	System.out.print("1. All team , 2 Specific Player \n");
	Scanner Sc = new Scanner(System.in) ;
	int a = Sc.nextInt();
	int Start = 0 ;
	int End = 0 ;
	if (a == 1) {Start =0 ;  End = Player.Team.size();};
	if (a==2) {
		System.out.print("Enter Name \n");
		Scanner S = new Scanner(System.in) ;	
    String N = S.nextLine();
	Start = Player.findIndexByName(N);
	End = Start +1 ;
	}
	for (int i = Start ; i < End ;i++) {
		Player.Team.get(i).Display();
	    System.out.print("\n");
	}
}
public static void DisplayStaffInfo() {
	System.out.print("1. All Staff , 2 Specific Staff \n");
	Scanner Sc = new Scanner(System.in) ;
	int a = Sc.nextInt();
	int Start = 0 ;
	int End = 0 ;
	if (a == 1) {Start =0 ;  End = Staff.AllStaff.size();};
	if (a==2) {
		System.out.print("Enter Name \n");
		Scanner S = new Scanner(System.in) ;	
    String N = S.nextLine();
	Start = Staff.findIndexByName(N);
	End = Start +1 ;
	}
	for (int i = Start ; i < End ;i++) {
		Staff.AllStaff.get(i).Display();
	    System.out.print("\n");
	}
}
public static void DisplayChampInfo() {
	System.out.print("1. All Games , 2 Specific Game \n");
	Scanner Sc = new Scanner(System.in) ;
	int a = Sc.nextInt();
	if(a==2) {
	
		System.out.print("Enter Name \n");
		Scanner S = new Scanner(System.in) ;	
       String N = S.nextLine();
     int Index = Game.findIndexByName(N);
     Game.Championship.get(Index).Display(); 
	}else {
	int won = 0 ;
	int lost = 0 ;
	int draw = 0;
	for (int i = 0 ; i < Game.Championship.size(); i++) {
		if (Game.Championship.get(i).getGoalsScored() > Game.Championship.get(i).getGoalsConceded()){
		won = won + 1 ;	
		}
		if (Game.Championship.get(i).getGoalsScored() < Game.Championship.get(i).getGoalsConceded()){
		lost = lost + 1 ;	
		}
		if (Game.Championship.get(i).getGoalsScored() == Game.Championship.get(i).getGoalsConceded()){
		draw = draw + 1 ;	
		}
		Game.Championship.get(i).Display();
	}
	System.out.print("WON = "+ won + " Lost = "+ lost+ " Draw = "+ draw + "\n");
	}
}

public static void updatePlayersStatus(Game G) {
	String[] GoalScorers = G.getGoalScorers().split(" ");
	String[] YellowCards = G.getYellowCardsGiven().split(" ");
	String[] RedCards = G.getRedCardsGiven().split(" ");
	String[] Assists = G.getAssists().split(" ");

    for (String a : GoalScorers) {
    int i = Player.findIndexByName(a);
    Player.Team.get(i).setGoalsScored(Player.Team.get(i).getGoalsScored()+1);
 }
    for (String a : YellowCards) {
        int i = Player.findIndexByName(a);
        Player.Team.get(i).setYellowCards(Player.Team.get(i).getYellowCards()+1);
     }
    for (String a : RedCards) {
        int i = Player.findIndexByName(a);
        Player.Team.get(i).setRedCards(Player.Team.get(i).getRedCards()+1);
     }
    for (String a : Assists) {
        int i = Player.findIndexByName(a);
        Player.Team.get(i).setAssists(Player.Team.get(i).getAssists()+1);
     }


}

public static void ReadPlayerData () {
	String csvFile = "src/Data.txt";
	BufferedReader br = null;
	String line = "";
	try {
      br = new BufferedReader(new FileReader(csvFile));
      while ((line = br.readLine()) != null) {
       String[] PlayerData = line.split(",");
         Player P = new Player(PlayerData[0],Integer.parseInt(PlayerData[1]),PlayerData[2],Integer.parseInt(PlayerData[3]),Integer.parseInt(PlayerData[4]),Integer.parseInt(PlayerData[5]),Integer.parseInt(PlayerData[6]),Integer.parseInt(PlayerData[7]),Integer.parseInt(PlayerData[8]));
         Player.Team.add(P);
      	}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}	
  }



}
public static void ReadStaffData () {
	String csvFile = "src/Staff.txt";
	BufferedReader br = null;
	String line = "";
	try {
      br = new BufferedReader(new FileReader(csvFile));
      while ((line = br.readLine()) != null) {
       String[] StaffData = line.split(",");
         Staff S = new Staff(StaffData[0],Integer.parseInt(StaffData[1]),StaffData[2],Integer.parseInt(StaffData[3]));
         Staff.AllStaff.add(S);

      	}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}	
  }



}
public static void ReadGameData () {
	String csvFile = "src/GamesData.txt";
	BufferedReader br = null;
	String line = "";
	try {
      br = new BufferedReader(new FileReader(csvFile));
      while ((line = br.readLine()) != null) {
       String[] GamesData = line.split(",");
        Game G = new Game(GamesData[0],Integer.parseInt(GamesData[1]),Integer.parseInt(GamesData[2]),GamesData[3],GamesData[4],GamesData[5],GamesData[6]);
        Game.Championship.add(G);
      	
      	}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}	
  }
}
public static String PlayerCSV(Player P) throws IOException {
	
	return  P.getName() +","+ P.getAge() + ","+ P.getPosition() + ","+ (int) P.getPrice() + ","+ (int) P.getSalary() + ","+P.getRedCards() + ","+P.getYellowCards()+ ","+P.getGoalsScored() + ","+P.getAssists();
	
}

public static String StafftoCSV(Staff S) throws IOException {
	
	return  S.getName() +","+ S.getAge() + ","+ S.getJob() +","+ (int) S.getSalary() ;
	
}
public static String GameCsv(Game G) throws IOException {
	
	return G.getOpponent() +","+ G.getGoalsConceded()+","+G.getGoalsScored()+","+G.getGoalScorers()+","+G.getYellowCardsGiven()+","+G.getRedCardsGiven()+","+G.getAssists();
	
}
public static void Save() {
    String Str="";
    try{
	File file = new File("src/Data.txt");
	FileWriter writer = new FileWriter(file) ;
	for (int i = 0; i< Player.Team.size();i++) {
	 Str = Str.concat(PlayerCSV(Player.Team.get(i)));
	 if (i<Player.Team.size()-1) {
	 Str =Str.concat("\n");
	  }
	
	 }
	writer.write(Str );
	writer.close();

    	}catch (Exception e){
		e.printStackTrace();
    	}
    String Str1="";
    
    try{
    	File file1 = new File("src/GamesData.txt");
    	FileWriter writer1 = new FileWriter(file1) ;
    	for (int i = 0; i< Game.Championship.size();i++) {
    	Str1 = Str1.concat(GameCsv(Game.Championship.get(i)));
    	 if (i < Game.Championship.size()-1) {
    		 Str1 = Str1.concat("\n");
    		  }
    	}
    	writer1.write(Str1);
    	writer1.close();

        	}catch (Exception e){
    		e.printStackTrace();
        	}
    String Str2 ="";
	 try{
	    	File file1 = new File("src/Staff.txt");
	    	FileWriter writer1 = new FileWriter(file1) ;
	    	for (int i = 0; i<Staff.AllStaff.size();i++) {
	    	Str2 = Str2.concat(StafftoCSV(Staff.AllStaff.get(i)));
	    	 if (i < Staff.AllStaff.size()-1) {
	    		 Str2 = Str2.concat("\n");
	    		  }
	    	}
	    	writer1.write(Str2);
	    	writer1.close();

	        	}catch (Exception e){
	    		e.printStackTrace();
	        	}
	       
   

}

}